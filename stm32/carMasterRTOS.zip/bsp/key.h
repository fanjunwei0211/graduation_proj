#ifndef __KEY_H
#define __KEY_H

#include "main.h"
#include "gpio.h"

int KeyState(int button);

#endif
