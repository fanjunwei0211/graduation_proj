#ifndef __LED_H
#define __LED_H

#include "main.h"
#include "gpio.h"
 
void Led_Flash(int count); 
 
#endif 
