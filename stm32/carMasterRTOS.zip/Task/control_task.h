#ifndef __CONTROL_TASK_H
#define __CONTROL_TASK_H

void Forword(int speed,int dis);
void CrossMove(int speed,int dis);

#endif  
