#ifndef _modbus_crc_h_
#define _modbus_crc_h_
#include "main.h"
//#include "stm32f10x.h"




uint16_t  Modbus_CRC16( uint8_t *puchMsg, uint16_t usDataLen );


#endif

